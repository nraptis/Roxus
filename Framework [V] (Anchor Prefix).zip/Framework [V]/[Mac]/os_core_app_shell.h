//Android needs this, so we have it here too.

#ifndef APP_SHELL_OS_H
#define APP_SHELL_OS_H

#include "core_app_shell.h"

extern "C"
{
    
};

int os_core_main (int argc, char **argv);

#endif // JNIAPI_H
