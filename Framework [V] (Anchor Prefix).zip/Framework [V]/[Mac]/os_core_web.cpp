//
//  os_core_web.cpp
//  2015 Gnome Launcher
//
//  Created by Nick Raptis on 11/22/14.
//  Copyright (c) 2014 Nick Raptis. All rights reserved.
//

#include "os_core_web.h"

//#include <iostream>
//#include <vector>
//#include <stdlib.h>
//#include <time.h>
//#include <algorithm>
//#include <chrono>


void os_web_Update()
{
    
}

void os_web_HTTPRequestMake(const char *pURL, int pRequestID)
{
    //printf("os_web_HTTPRequestMake(%s, %d)\n\n", pURL, pRequestID);
    
}

bool os_web_HTTPRequestDidComplete(int pRequestID)
{
    bool aResult = false;
    
    return aResult;
}

bool os_web_HTTPRequestDidFail(int pRequestID)
{
    bool aResult = false;
    
    return aResult;
}

bool os_web_HTTPRequestDidSucceed(int pRequestID)
{
    bool aResult = false;
    
    return aResult;
}

char *os_web_HTTPRequestData(int pRequestID)
{
    char *aResult = 0;
    
    
    
    return aResult;
}

void os_web_HTTPRequestPurge(int pRequestID)
{
    
}
