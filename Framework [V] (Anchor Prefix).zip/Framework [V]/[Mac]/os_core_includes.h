
#ifndef CORE_INCLUDES_IOS_H
#define CORE_INCLUDES_IOS_H

#define MAC_ENVIRONMENT 1

#include <GLUT/glut.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>

//#include <GL/glut.h>
//#include <GL/glu.h>
//#include <GL/gl.h>

#include <stdlib.h>
#include <iostream>
#include <fstream>

#endif
