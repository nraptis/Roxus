//
//  OSInputGrabber.h
//  DigMMMac
//
//  Created by Nicholas Raptis on 2/6/15.
//  Copyright (c) 2015 Nick Raptis. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

@interface OSInputGrabber : NSObject

@end
