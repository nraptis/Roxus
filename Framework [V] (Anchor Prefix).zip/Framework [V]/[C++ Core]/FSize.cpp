//
//  FSize.cpp
//  DigMMMac
//
//  Created by Raptis, Nicholas on 5/13/16.
//  Copyright © 2016 Darkswarm LLC. All rights reserved.
//

#include "FSize.h"
