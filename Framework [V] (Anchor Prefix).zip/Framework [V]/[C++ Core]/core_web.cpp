//
//  core_web.cpp
//  2015 Gnome Launcher
//
//  Created by Nick Raptis on 11/22/14.
//  Copyright (c) 2014 Nick Raptis. All rights reserved.
//

#include "core_web.h"
#include "os_core_web.h"

void core_web_openURL(const char *pURL)
{
    
}

bool core_web_hasConnection()
{
    bool aResult = false;
    
    
    
    return aResult;
}
