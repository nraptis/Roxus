//
//  core_web.h
//  2015 Gnome Launcher
//
//  Created by Nick Raptis on 11/22/14.
//  Copyright (c) 2014 Nick Raptis. All rights reserved.
//

#ifndef ___015_Fleet_XP__core_web__
#define ___015_Fleet_XP__core_web__

void                            core_web_openURL(const char *pURL);

bool                            core_web_hasConnection();






#endif /* defined(___015_Fleet_XP__core_web__) */
