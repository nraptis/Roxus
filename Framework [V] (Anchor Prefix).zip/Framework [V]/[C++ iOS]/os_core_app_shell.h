//Android needs this, se we have it here too. See how that works?

#ifndef APP_SHELL_OS_H
#define APP_SHELL_OS_H

extern "C"
{
    
};

#endif // JNIAPI_H
