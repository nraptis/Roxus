
#ifndef CORE_INCLUDES_IOS_H
#define CORE_INCLUDES_IOS_H

#include <OpenGLES/ES1/gl.h>
#include <OpenGLES/ES1/glext.h>

#endif
