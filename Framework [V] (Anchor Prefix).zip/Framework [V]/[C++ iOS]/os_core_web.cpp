//
//  os_core_web.cpp
//  2015 Fleet XP
//
//  Created by Nick Raptis on 11/22/14.
//  Copyright (c) 2014 Applejacks Microsoft Cloud Wizzywig Pippy Longstocking. All rights reserved.
//

#include "os_core_web.h"

#include <iostream>
#include <vector>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <algorithm>    // std::sort
//#include <chrono>


void os_web_Update()
{
    
}

void os_web_HTTPRequestMake(const char *pURL, int pRequestID)
{
    printf("os_web_HTTPRequestMake(%s, %d)\n\n", pURL, pRequestID);
}

bool os_web_HTTPRequestDidComplete(int pRequestID)
{
    bool aReturn = false;
    
    return aReturn;
}

bool os_web_HTTPRequestDidFail(int pRequestID)
{
    bool aReturn = false;
    
    return aReturn;
}

bool os_web_HTTPRequestDidSucceed(int pRequestID)
{
    bool aReturn = false;
    
    return aReturn;
}

char *os_web_HTTPRequestData(int pRequestID)
{
    char *aReturn = 0;
    
    
    
    return aReturn;
}

void os_web_HTTPRequestPurge(int pRequestID)
{
    
}
