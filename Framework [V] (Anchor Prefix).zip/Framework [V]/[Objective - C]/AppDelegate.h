
#import <UIKit/UIKit.h>
#import "Root.h"

#define LANDSCAPE_MODE 1
#undef LANDSCAPE_MODE

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) Root *rootViewController;

@end









